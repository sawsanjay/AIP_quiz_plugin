jQuery(document).ready(function($) {
    $('#product-filter').submit(function(e) {
        e.preventDefault();

        var data = {
            action: 'get_quiz',
            category: $('input[name="category[]"]:checked').map(function() {
                return this.value;
            }).get()
        };
        console.log(data);
        $.ajax({
            url: ajax_object.ajax_url,
            type: 'POST',
            data: data,
            success: function(response) {
                $('.posts-area').html(response);
              
            },
            error: function(xhr, ajaxOptions, thrownError) {
                alert('An error occurred. Please try again.');
            }
        });
    });

    jQuery("#calculate").click(function() {
        var part = parseInt(jQuery("#score_value").text());
        var whole = parseInt(jQuery("#total_value").text());
        
        var percentage = (part / whole) * 100;
        if(percentage < 50){
            $('#status_value').html('<div class="alert alert-danger" role="alert">Fail</div>');
        }
        else{
            $('#status_value').html('<div class="alert alert-success" role="alert">Pass</div>');
        }
                
        jQuery("#percentage_value").text(percentage.toFixed(2)+"%");
    });
});









