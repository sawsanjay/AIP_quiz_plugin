<?php 
/**
 * Plugin Name: Quiz plugin
 * Description: A plugin for online quize system.
 * Version: 1.0
 * Author: sanjay saw
 * Author URI: https://github.com/sawsanjay/quiz_plugin.git
 * Text Domain: quiz-plugin
 */
 
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

define( 'QUIZPLUGIN_VERSION', '5.1' );
define( 'QUIZPLUGIN__MINIMUM_WP_VERSION', '5.0' );
define( 'QUIZPLUGIN__PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'QUIZPLUGIN_DELETE_LIMIT', 10000 );

function enqueue_product_scripts() {
  wp_enqueue_style( 'quiz-post-plugin-css',plugin_dir_url( __FILE__ ) . 'assets/css/product-post-style.css', '1.1.1', true );
  wp_enqueue_script('jquery');
  wp_enqueue_script( 'jquery-validate', 'http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js', array( 'jquery' ), '1.11.22', true );
  wp_enqueue_script('quiz-archive-script', plugin_dir_url( __FILE__ ) . 'assets/js/quiz-archive.js', array('jquery'), '1.2.3', true);
  wp_localize_script('quiz-archive-script', 'ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
}
add_action('wp_enqueue_scripts', 'enqueue_product_scripts');

require_once( QUIZPLUGIN__PLUGIN_DIR . 'classes/class.custom-quiz-post.php' );
require_once( QUIZPLUGIN__PLUGIN_DIR . 'classes/class.quiz-archive-page-ajax.php');
//require_once( QUIZPLUGIN__PLUGIN_DIR . 'classes/class.custom-quiz-single-template.php');
require_once( QUIZPLUGIN__PLUGIN_DIR . 'classes/class.custom-quiz-shortcodes.php');


register_activation_hook( __FILE__, 'activate');
register_deactivation_hook( __FILE__,'deactivate');

function activate() {
  add_quiz_archive_page();
}

function deactivate() {
  delete_my_all_custom_archive_page();
}

function add_quiz_archive_page() {
  $page_title = 'quiz';
  $page_content = '[quiz_archive]';
  $page = array(
      'post_title'     => $page_title,
      'post_content'   => $page_content,
      'post_status'    => 'publish',
      'post_type'      => 'page',
      'post_author'    => 1,
      'post_name'      => 'quiz'
  );
  wp_insert_post( $page );
}
function delete_my_all_custom_archive_page() {
  wp_delete_post(get_page_by_path('quiz')->ID, true);
}
?>