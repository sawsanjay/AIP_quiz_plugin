 
<?php
get_header(); 
?>
<section>
	<div class="row">

		<div class="col-lg-9 col-md-8 col-sm-12">
		<h3>Select quiz language from sied bar and start your quiz</h3>
			<div class="product_list">
				<div class=" posts-area">
				</div><br>
			</div>
		</div>

		<div class="col-lg-3 col-md-4 col-sm-12">
			<form id="product-filter" method="POST">
				<div class="product_cat_main ">
					<label style="width: 100%">Category: </label>
					<?php
					$args = array( 'taxonomy' => 'quiz_category', 'orderby' => 'name', 'order' => 'ASC' );
					$categories = get_categories($args);
					foreach($categories as $category) { ?> 
						<input type="checkbox" name="category[]" value="<?php echo $category->name; ?>"> <?php echo strtoupper($category->name) ; ?><br>
					<?php  
					} ?>
				</div> 
				<div style="text-align:right;"><input type="submit"  value="Get Questions"></div>
				
				<!-- <div style="text-align:left;"><a href="<?php// echo get_site_url()?>/quiz" >Clear Filter</a></div> -->
				
				<lable>Percentage: <span id="percentage_value"></span></lable><br>
				<lable>Status: <span id="status_value"></span></lable><br>
				<span id="calculate" class="btn btn-primary">Show Result</span>
			</form>
		</div>
	</div>
</section>
<?php get_footer(); ?>