<?php
/**
 * Template Name: Single Quiz
 * Template Post Type: quiz
 */
get_header(); 
?>
  <div class="container">
  <h1>Quiz Page</h1>
  <hr>
  <br><br>
    <div class="row">
      <div class="col-md-6">
      <div class="col-md-6">
        <h3><?php echo get_the_title(); ?></h3>
       
      </div>
    </div>
  </div>
<?php
get_footer();
?>
