<?php

class Custom_Quiz_Post {
    public function __construct() {
        add_action('init', array($this, 'register_custom_post_type'));
        add_action( 'init', array($this, 'add_custom_screen_option'));
    }

    public function add_custom_screen_option() {
        $post_type = 'quiz'; // Replace with your custom post type slug
        add_post_type_support( $post_type, 'custom-fields' );
      }
      

    public function register_custom_post_type() {
        register_post_type('quiz', [
            'label' => __('AIP Quiz', 'txtdomain'),
            'public' => true,
            'menu_position' => 5,
            'menu_icon' => 'dashicons-book',
            'supports' => ['title', 'editor', 'thumbnail', 'author', 'revisions', 'comments'],
            'show_in_rest' => true,
            'rewrite' => ['slug' => 'quiz'],
            'taxonomies' => ['quiz_category'],
            'labels' => [
                'singular_name' => __('questions', 'txtdomain'),
                'add_new_item' => __('Add new question', 'txtdomain'),
                'new_item' => __('New question', 'txtdomain'),
                'view_item' => __('View question', 'txtdomain'),
                'not_found' => __('No questiones found', 'txtdomain'),
                'not_found_in_trash' => __('No questions found in trash', 'txtdomain'),
                'all_items' => __('All Questions', 'txtdomain'),
                'insert_into_item' => __('Insert into questions', 'txtdomain')
            ],		
        ]);
        register_taxonomy('quiz_category', ['quiz'], [
            'label' => __('Quiz Category', 'txtdomain'),
            'hierarchical' => true,
            'rewrite' => ['slug' => 'quiz-category'],
            'show_admin_column' => true,
            'show_in_rest' => true,
            'labels' => [
                'singular_name' => __('Category', 'txtdomain'),
                'all_items' => __('All Categorys', 'txtdomain'),
                'edit_item' => __('Edit Category', 'txtdomain'),
                'view_item' => __('View Category', 'txtdomain'),
                'update_item' => __('Update Category', 'txtdomain'),
                'add_new_item' => __('Add New Category', 'txtdomain'),
                'new_item_name' => __('New Category Name', 'txtdomain'),
                'search_items' => __('Search Categorys', 'txtdomain'),
                'popular_items' => __('Popular Categorys', 'txtdomain'),
                'separate_items_with_commas' => __('Separate Categorys with comma', 'txtdomain'),
                'choose_from_most_used' => __('Choose from most used Categorys', 'txtdomain'),
                'not_found' => __('No Categorys found', 'txtdomain'),
            ]
        ]);
        register_taxonomy_for_object_type('quiz_category', 'quiz');
    }
}
$Custom_Quiz_Post = new Custom_Quiz_Post();
    
    
