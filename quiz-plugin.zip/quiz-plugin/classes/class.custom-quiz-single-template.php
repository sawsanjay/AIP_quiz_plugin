<?php
class Custom_Quiz_Single_Template {

  public function __construct() {
    add_filter('single_template', array($this, 'quiz_single_template'));
  }

  public function quiz_single_template($single_template) {
    global $post;
    if ($post->post_type == 'quiz') {
        $single_template = QUIZPLUGIN__PLUGIN_DIR . 'templates/single-quiz.php';
    }
    return $single_template;
  }
}
$Custom_Quiz_Single_Template = new Custom_Quiz_Single_Template();
    
    
