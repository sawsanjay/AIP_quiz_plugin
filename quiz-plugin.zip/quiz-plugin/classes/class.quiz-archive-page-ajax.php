<?php

class Quiz_Archive_Page_Ajax {
    public function __construct() {
      
        add_action('wp_ajax_get_quiz', array($this, 'get_quiz'));
        add_action('wp_ajax_nopriv_get_quiz', array($this, 'get_quiz'));
    }

    public function get_quiz() {
      $args = array(
          'post_type' => 'quiz',
          'posts_per_page' => -1,
          'meta_query' => array(),
          'tax_query' => array()
      );
    
  
      if (isset($_POST['category']) && !empty($_POST['category'])) {
          $args['tax_query'][] = array(
              'taxonomy' => 'quiz_category',
              'field' => 'slug',
              'terms' => $_POST['category']
          );
      }
  
      $query = new WP_Query($args);
      $total_count = $query->found_posts;
      $n = 1;
      if ($query->have_posts()) {
          while ($query->have_posts()) {
              $query->the_post(); ?>
          <?php if($n == 1){ ?>
            <lable>Score: <span id="score_value">0</span>/<span id="total_value"><?php echo $total_count ?></span></lable>
          <?php } ?>
          <p>
            <h5><span>(<?php echo $n; ?>). </span><?php echo get_the_title(); ?></h5>
          </p>
          <ol style="list-style-type: upper-alpha;">
            <li >
              <?php echo $custom_field_value = get_post_meta( get_the_id(), 'A', true ); ?>
              <input type="radio" name="radio_<?php echo $n; ?>" value="A"  id="a<?php echo $n; ?>"/>
            </li>
            <li>
              <?php echo $custom_field_value = get_post_meta( get_the_id(), 'B', true ); ?>
              <input type="radio"  name="radio_<?php echo $n; ?>" value="B" id="b<?php echo $n; ?>"/>
            </li>
          </ol>
          <p id = "rightElement<?php echo $n; ?>" style = 'display: none;'><?php echo $custom_field_value = get_post_meta( get_the_id(), 'Ans', true ); ?></p>
          <p id="message<?php echo $n; ?>"></p>

          <script>

            $(document).ready(function() {
              $('#a<?php echo $n; ?>').click(function() {
                var targetElement1 = $('#a<?php echo $n; ?>').val(); 
                var rightElement = $('#rightElement<?php echo $n; ?>').text();

                if (rightElement === targetElement1) {
                  var scorevalue = $('#score_value').text();
                  var value = parseInt(scorevalue);
                  var newValue = value + 1;
                  $('#score_value').text(newValue);
                  $('#message<?php echo $n; ?>').html('<div class="alert alert-success" role="alert">Right</div>'); 
                  $('input[name="radio_<?php echo $n; ?>"]').prop('disabled', true);
                }
                else{
                  $('#message<?php echo $n; ?>').html('<div class="alert alert-danger" role="alert">Wrong</div>');
                  $('input[name="radio_<?php echo $n; ?>"]').prop('disabled', true);
                }
              });
              $('#b<?php echo $n; ?>').click(function() {
              
                var targetElement2 = $('#b<?php echo $n; ?>').val();  
                var rightElement = $('#rightElement<?php echo $n; ?>').text(); 

                if (rightElement === targetElement2) {
                  var scorevalue = $('#score_value').text();
                  var value = parseInt(scorevalue);
                  var newValue = value + 1;
                  $('#score_value').text(newValue);
               
                  $('#message<?php echo $n; ?>').html('<div class="alert alert-success" role="alert">Right</div>'); 
                  $('input[name="radio_<?php echo $n; ?>"]').prop('disabled', true);
                } 
                else{
                  $('#message<?php echo $n; ?>').html('<div class="alert alert-danger" role="alert">Wrong</div>'); 
                  $('input[name="radio_<?php echo $n; ?>"]').prop('disabled', true);
                }
              });
            });
          </script>


                   
                  
    <?php $n++;
          }
          wp_reset_postdata();
      } else {
          echo 'No quizs found.';
      }
      die();
    }

 
}
// Instantiate the plugin class
$Quiz_Archive_Page_Ajax = new Quiz_Archive_Page_Ajax();
    
    
