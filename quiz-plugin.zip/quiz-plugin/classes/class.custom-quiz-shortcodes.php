<?php

class Custom_Quiz_Shortcodes {
    public function __construct() {
      add_shortcode('quiz_archive', array($this, 'quiz_archive_shortcode'));
    }

    public function quiz_archive_shortcode() {
      ob_start();
      require_once( QUIZPLUGIN__PLUGIN_DIR . 'templates/archive-quiz.php');
      return ob_get_clean();
    }
   
}
$Custom_Quiz_Shortcodes = new Custom_Quiz_Shortcodes();
    
    
